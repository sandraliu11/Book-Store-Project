﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: Allows user to enter an ISBN to either add, update or delete a book

namespace BookstoreProject
{
    public partial class frmTransactionSelect : Form
    {
        public frmTransactionSelect()
        {
            InitializeComponent();
            // Hide unnecessary controls
            lblSelectTransaction.Visible = false;
            btnAddNewBook.Visible = false;
            btnUpdateBook.Visible = false;
            btnDeleteBook.Visible = false;
            btnDoneAdd.Visible = false;
            btnDoneUpdate.Visible = false;
            grpInventoryChangeControls.Visible = false;
        }
        string bookString;
        int recordsReadCount;
        int recordsWrittenCount = 0;
        string ISBN;
        private bool foundISBN;
        private bool foundDuplicate;
        string[] bookData;
        string[] displayString;

        // Validates ISBN entered to display further controls
        private void btnOk_Click(object sender, EventArgs e)
        {
            //btnOk.Enabled = true;
            validateISBN();
            if (validateISBN() == false) // Tell user their ISBN is not valid format
            {
                MessageBox.Show("ISBN must be a 6-digit number format.");

            }
            else
            {
                btnOk.Enabled = false;
                btnAddNewBook.Enabled = true;
                btnUpdateBook.Enabled = true;
                btnDeleteBook.Enabled = true;

                txtISBN1.Enabled = false;
                txtISBN2.Enabled = false;

                //txtISBN1.Text = "";
                //txtISBN2.Text = "";
                validateISBN();
                //Globals.BookStore.rewindFiles();
            }
        }

        // Add new book into list 
        private void btnAddNewBook_Click(object sender, EventArgs e)
        {
            // Disable unnecessary controls
            txtISBN1.Enabled = false;
            txtISBN2.Enabled = false;
            txtISBN.Enabled = true;
            txtTitle.Enabled = true;
            txtAuthor.Enabled = true;
            txtPrice.Enabled = true;
            txtOnHand.Enabled = true;
            txtTransactionDate.Enabled = true;
            btnAddNewBook.Enabled = false;
            btnUpdateBook.Enabled = false;
            btnDeleteBook.Enabled = false;
            btnOk.Enabled = false;
            btnYes.Visible = false;
            btnNo.Visible = false;
            txtISBN.Enabled = false;
            txtTransactionDate.Enabled = false;
            DateTime date = DateTime.Today;
            txtTransactionDate.Text = Convert.ToString(date);
            txtISBN.Text = txtISBN1.Text + txtISBN2.Text;
            ISBN = Convert.ToString(txtISBN1.Text) + Convert.ToString(txtISBN2.Text);
            MessageBox.Show(ISBN);
            foundDuplicate = Globals.BookStore.checkForDuplicateRecord(ISBN);
            MessageBox.Show("ISBN found: " + foundDuplicate);
            this.AcceptButton = btnDoneAdd;
            if (foundDuplicate == true) // Duplicate book with same ISBN found, so asks user for another ISBN to add new book
            {
                MessageBox.Show("Sorry, this ISBN is already on file. Please enter another.",
                            "ISBN Already Exists", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // Disable unnecessary controls
                btnOk.Enabled = true;
                txtISBN1.Enabled = true;
                txtISBN2.Enabled = true;
                lblSelectTransaction.Visible = false;
                btnAddNewBook.Enabled = true;
                btnUpdateBook.Enabled = true;
                btnDeleteBook.Enabled = true;
                btnAddNewBook.Visible = false;
                btnUpdateBook.Visible = false;
                btnDeleteBook.Visible = false;
                AcceptButton = btnOk;
                txtISBN1.Text = "";
                txtISBN2.Text = "";
                txtISBN1.Focus();
                Globals.BookStore.rewindFiles();
            }
            else // Displays controls to user needed to add a new book
            {
                // Display necessary controls
                grpInventoryChangeControls.Visible = true;
                btnDoneAdd.Visible = true; // follow through to done to finish adding
                txtTitle.Focus();
            }
        }

        // Update a book already in list
        private void btnUpdateBook_Click(object sender, EventArgs e)
        {
            // Disable unnecessary controls
            btnAddNewBook.Enabled = false;
            btnUpdateBook.Enabled = false;
            btnDeleteBook.Enabled = false;
            txtISBN1.Enabled = false;
            txtISBN2.Enabled = false;
            txtTitle.Enabled = true;
            txtAuthor.Enabled = true;
            txtPrice.Enabled = true;
            txtOnHand.Enabled = true;
            txtTransactionDate.Enabled = true;
            btnOk.Enabled = false;
            btnYes.Visible = false;
            btnNo.Visible = false;
            txtISBN.Enabled = false;
            txtTransactionDate.Enabled = false;

            // Display to user new date/ convert isbn
            DateTime date = DateTime.Today;
            txtTransactionDate.Text = Convert.ToString(date);
            txtISBN.Text = txtISBN1.Text + txtISBN2.Text;
            ISBN = Convert.ToString(txtISBN1.Text) + Convert.ToString(txtISBN2.Text);
            // Display current book data
            displayString = Globals.BookStore.bookStringToDisplay(ISBN);
            txtTitle.Text = displayString[1];
            txtAuthor.Text = displayString[2];
            txtPrice.Text = displayString[3];
            txtOnHand.Text = displayString[4];
            foundDuplicate = Globals.BookStore.checkForDuplicateRecord(ISBN); // Checks ISBN already on file
            MessageBox.Show("ISBN found: " + foundDuplicate);
            this.AcceptButton = btnDoneUpdate;
            if (foundDuplicate == false) // Book cannot be updated bc ISBN is not on record, tells user to re-enter
            {
                MessageBox.Show("Sorry, this ISBN is not on file. To update, please add book first.",
                            "ISBN Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // Disable unnecessary controls
                btnOk.Enabled = true;
                txtISBN1.Enabled = true;
                txtISBN2.Enabled = true;
                lblSelectTransaction.Visible = false;
                btnAddNewBook.Enabled = true;
                btnUpdateBook.Enabled = true;
                btnDeleteBook.Enabled = true;
                btnAddNewBook.Visible = false;
                btnUpdateBook.Visible = false;
                btnDeleteBook.Visible = false;
                AcceptButton = btnOk;
                txtISBN1.Text = "";
                txtISBN2.Text = "";
                txtISBN1.Focus();
                //Globals.BookStore.rewindFiles();
            }
            else // Displays controls needed for user to update a book
            {
                // Display necessary controls
                grpInventoryChangeControls.Visible = true;
                btnDoneUpdate.Visible = true; // follow through to done to finish updating
                txtISBN.Enabled = false;
                txtTitle.Focus();
                lblEnterData.Text = "Update necessary data below then click done.";
            }
            // Display necessary controls
        }

        // Delete a book already in list
        private void btnDeleteBook_Click(object sender, EventArgs e)
        {
            // Disable unnecessary controls
            btnAddNewBook.Enabled = false;
            btnUpdateBook.Enabled = false;
            btnDeleteBook.Enabled = false;
            txtISBN1.Enabled = false;
            txtISBN2.Enabled = false;
            btnOk.Enabled = false;
            btnDoneAdd.Visible = false;
            txtISBN.Enabled = false;
            txtISBN.Text = txtISBN1.Text + txtISBN2.Text;
            txtTransactionDate.Enabled = false;
            DateTime date = DateTime.Today;
            txtTransactionDate.Text = Convert.ToString(date);
            ISBN = Convert.ToString(txtISBN1.Text) + Convert.ToString(txtISBN2.Text);
            displayString = Globals.BookStore.bookStringToDisplay(ISBN);
            txtTitle.Text = displayString[1];
            txtAuthor.Text = displayString[2];
            txtPrice.Text = displayString[3];
            txtOnHand.Text = displayString[4];
            this.AcceptButton = btnYes;

            foundISBN = Globals.BookStore.checkForDuplicateRecord(ISBN);
            MessageBox.Show("ISBN found: " + foundISBN);
            if (foundISBN == true) // Double checks with user if they really want to delete that book
            {
                // Display necessary controls
                grpInventoryChangeControls.Visible = true;
                txtAuthor.Enabled = false;
                txtISBN.Enabled = false;
                txtTitle.Enabled = false;
                txtPrice.Enabled = false;
                txtOnHand.Enabled = false;
                txtTransactionDate.Enabled = false;
                lblEnterData.Visible = true;
                btnNo.Visible = true;
                btnYes.Visible = true;
                lblEnterData.Text = "Are you sure you want to delete this book?";
                btnNo.Focus();
            }
            else // Tells user this book does not exist and to enter another ISBN
            {
                MessageBox.Show("The entered ISBN does not exist. Cannot delete this book.",
                            "ISBN Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // Disable unnecessary controls
                btnOk.Enabled = true;
                txtISBN1.Enabled = true;
                txtISBN2.Enabled = true;
                lblSelectTransaction.Visible = false;
                btnAddNewBook.Enabled = true;
                btnUpdateBook.Enabled = true;
                btnDeleteBook.Enabled = true;
                btnAddNewBook.Visible = false;
                btnUpdateBook.Visible = false;
                btnDeleteBook.Visible = false;
                AcceptButton = btnOk;
                txtISBN1.Text = "";
                txtISBN2.Text = "";
                txtISBN1.Focus();
                //Globals.BookStore.rewindFiles();
            }

        }

        // Submits data entered to add/update/delete a book
        private void btnDoneAdd_Click(object sender, EventArgs e)
        {
            recordsWrittenCount = 0;
            bool validData = validateTransactionData();
            //btnDone.Visible = false;
            if (validData == false) //Asks user to re-enter data
            {
                MessageBox.Show("Data entered is invalid. Please re-enter.");
            }
            else if (validData == true) // Allows data to be written to file
            {
                DateTime date = DateTime.Today;
                txtTransactionDate.Text = Convert.ToString(date);
                bookString = (txtISBN.Text + '*' + txtTitle.Text + '*' + txtAuthor.Text +
                    '*' + txtPrice.Text + '*' + txtOnHand.Text + '*' + date);
                Globals.BookStore.writeOneRecord(bookString);
                Globals.BookStore.closeFiles();
                MessageBox.Show("Book record has been updated/added to file.");
                MessageBox.Show("Entered book string: " + bookString);
                recordsReadCount = BookStore.currentBookFile.getRecordsReadCount();
                recordsWrittenCount = Globals.BookStore.getWrittenCount() + recordsReadCount;
                MessageBox.Show("Number of records read: " + recordsReadCount + "\r\nNumber of records written: " +
                    recordsWrittenCount);
                MessageBox.Show("Exiting Form.");
                Close();

            }
        }

        //Exits transaction select form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            // Closes all files
            Globals.BookStore.closeFiles();
        }

        // Validates the first entered ISBN for all ints
        private bool ValidateISBNChar()
        {
            int val;
            if (int.TryParse(txtISBN1.Text, out val) || int.TryParse(txtISBN2.Text, out val))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Validates ISBN for numbers only and length of 6-digits
        private bool validateISBN()
        {
            if (txtISBN1.Text.Length != 3 || txtISBN2.Text.Length != 3 || ValidateISBNChar() == false)
            {
                //MessageBox.Show("ISBN must be 6-digits long. Please Re-enter.");
                txtISBN1.Focus();
                if (!(Regex.IsMatch(txtISBN1.Text, @"^[1-9---]+$")) || !(Regex.IsMatch(txtISBN2.Text, @"^[1-9---]+$")))
                {
                    //MessageBox.Show("ISBN must contain numbers only. Please Re-enter.");
                    txtISBN1.Focus();
                    txtISBN1.Clear();
                    txtISBN2.Clear();
                }
                return false;
            }
            else
            {
                // Display necessary controls
                btnOk.Enabled = false;
                lblSelectTransaction.Visible = true;
                btnAddNewBook.Visible = true;
                btnUpdateBook.Visible = true;
                btnDeleteBook.Visible = true;
                return true;
            }
            //return true;
        }

        // Validates length and structure of entered data of book record
        private bool validateTransactionData()
        {
            // Validate ISBN attribute
            if (txtISBN.Text.Length != 6)
            {
                MessageBox.Show("ISBN must be 6-digits long. Please Re-enter.");
                txtISBN.Focus();
                if (!(Regex.IsMatch(txtISBN.Text, @"^[1-9-]+$")))
                {
                    MessageBox.Show("ISBN must contain numbers only. Please Re-enter.");
                    txtISBN.Focus();
                    return false;
                }
                return false;
            }
            // Validate title attribute
            if (!(Regex.IsMatch(txtTitle.Text, @"^[A-Z-a-z- -]+$")))
            {
                MessageBox.Show("Title must contain letters. Please Re-enter.");
                txtTitle.Focus();
                return false;
            }
            // Validate author attribute
            if (!(Regex.IsMatch(txtAuthor.Text, @"^[A-Z-a-z- -]+$")))
            {
                MessageBox.Show("Author must contain letters. Please Re-enter.");
                txtAuthor.Focus();
                return false;
            }
            // Validate price attribute
            if (!(Regex.IsMatch(txtPrice.Text, @"^[0-9-$-.-,-]+$")))
            {
                MessageBox.Show("Price must be in numerical or $X.XX format. Please Re-enter.");
                txtPrice.Focus();
                return false;
            }
            // Validate on hold attribute
            if (!(Regex.IsMatch(txtOnHand.Text, @"^[0-9-]+$")))
            {
                MessageBox.Show("On hand # must contain numbers only. Please Re-enter.");
                txtOnHand.Focus();
                return false;
            }
            // Validate transaction date attribute
            if (txtTransactionDate.Text == "")
            {
                MessageBox.Show("Transaction date cannot be left blank. Please Re-enter.");
                txtTransactionDate.Focus();
                if (!(Regex.IsMatch(txtTransactionDate.Text, @"^[0-9---]+$")))
                {
                    MessageBox.Show("Transaction date must be in mm/dd/yyyy format. Please Re-enter.");
                    txtTransactionDate.Focus();
                    return false;
                }
                return false;
            }
            else
            {
                return true;
            }
        }

        // Move to next textbox for ISBN number enter
        private void txtISBN1_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToString(txtISBN1).Length == 3)
            {
                TextBox textBox = this.ActiveControl as TextBox;
                txtISBN2.Select();
                txtISBN2.Focus();
                if (textBox == txtISBN1)
                {
                    ActiveControl = txtISBN2;
                }
            }
        }

        // Creates book object during form load
        private void frmTransactionSelect_Load(object sender, EventArgs e)
        {
            Globals.BookStore.book.createBookObject(Globals.BookStore.bookFileText);
        }

        // User is sure that book is to be deleted, does not write out deleted book data
        private void btnYes_Click(object sender, EventArgs e)
        {
            Globals.BookStore.copyRemainingRecords(); //Writes all except found isbn
            Globals.BookStore.closeFiles();
            recordsReadCount = BookStore.currentBookFile.getRecordsReadCount();
            recordsWrittenCount = BookStore.currentBookFile.getRecordsReadCount() - 1;
            MessageBox.Show("Book record has been deleted.");
            MessageBox.Show("Number of records read: " + recordsReadCount + "\r\nNumber of records written: " +
                    recordsWrittenCount);
            MessageBox.Show("Exiting Form.");
            Close();
        }

        // Does not delete book and lets user exit or complete other transaction
        private void btnNo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Book record has not been deleted. Exiting application.");
            Close();
        }

        // Updates book, prints out to file, closes application
        private void btnDoneUpdate_Click(object sender, EventArgs e)
        {
            recordsWrittenCount = 0;
            bool validData = validateTransactionData();
            if (validData == false) //Asks user to re-enter data
            {
                MessageBox.Show("Data entered is invalid. Please re-enter.");
            }
            else if (validData == true) // Allows data to be written to file
            {
                DateTime date = DateTime.Today;
                txtTransactionDate.Text = Convert.ToString(date);
                bookString = (txtISBN.Text + '*' + txtTitle.Text + '*' + txtAuthor.Text +
                    '*' + txtPrice.Text + '*' + txtOnHand.Text + '*' + date);
                Globals.BookStore.writeOneRecord(bookString);
                Globals.BookStore.copyRemainingRecords();
                Globals.BookStore.closeFiles();
                MessageBox.Show("Book record has been updated/added to file.");
                MessageBox.Show("Entered book string: " + bookString);
                recordsReadCount = BookStore.currentBookFile.getRecordsReadCount();
                recordsWrittenCount = BookStore.updatedBookFile.getRecordsWrittenCount();
                MessageBox.Show("Number of records read: " + recordsReadCount + "\r\nNumber of records written: " +
                    recordsReadCount);
                MessageBox.Show("Exiting Form.");
                Close();
            }
        }

    }

}
