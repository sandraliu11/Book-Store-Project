﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: To create a streamwriter object to write out into files updated and added book data/updated employee data
namespace BookstoreProject
{
    class UpdatedFile
    {
        private string updatedBookFilePath;
        private System.IO.StreamWriter updatedFileSW; //Variable to reference type StreamWriter
        private int recordsWrittenCount;

        // Constructor for updated file streamwriter object
        public UpdatedFile(string updatedBookFilePath)
        {
            this.updatedBookFilePath = updatedBookFilePath;
            recordsWrittenCount = 0;

            try
            {
                updatedFileSW = new System.IO.StreamWriter(updatedBookFilePath);
            }

            catch (Exception e)
            {
                MessageBox.Show("File path error: " + updatedBookFilePath);
            }
        }

        // Gets number of written records
        public int getRecordsWrittenCount()
        {
            return recordsWrittenCount;
        }

        // Print out the next record to file
        public void putNextRecord(string record) //break
        {
            try
            {
                updatedFileSW.WriteLine(record);
            }
            catch (Exception e)
            {
                MessageBox.Show("Error occured writing into file.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        // Closes Streamwriter object
        public void closeFile()
        {
            updatedFileSW.Close();
        }
    
        // Rewind the input file
        public void rewindFile()
        {
            recordsWrittenCount = 0;
            updatedFileSW.Flush();
            updatedFileSW.BaseStream.Seek(0, System.IO.SeekOrigin.Begin);
        }  // end rewindFile
    }
}
