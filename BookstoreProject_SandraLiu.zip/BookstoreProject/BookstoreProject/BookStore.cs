﻿// BookStore Class 
// Contains constants, properties and other data related to the Bookstore
//     Frank Friedman
//     CIS 3309

//     Created on January 13 by FLF
//     Modified ... January 30, 2017

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: Owns all the files in this project and connects the lower layers of employee and book with the surface level form

namespace BookstoreProject
{
    class BookStore
    {
        // Books and the EmployeeList and all the text files belong to the Bookstore
        public EmployeeList empList = new EmployeeList();
        public Book book = new Book();
        public string bookFileText = File.ReadAllText(@"currentBookFile.txt");

        // The Files the Bookstore Owns
        private static string currentBookFilePath = "currentBookFile.txt";
        private static string updatedBookFilePath = "updatedBookFile.txt";
        private static string currentEmployeeFilePath = "currentEmployeeFile.txt";
        private static string updatedEmployeeFilePath = "updatedEmployeeFile.txt";

        public static CurrentFile currentBookFile = new CurrentFile(currentBookFilePath);
        public static UpdatedFile updatedBookFile = new UpdatedFile(updatedBookFilePath);
        public static CurrentFile currentEmployeeFile = new CurrentFile(currentEmployeeFilePath);
        public static UpdatedFile updatedEmployeeFile = new UpdatedFile(updatedEmployeeFilePath);

        // Bookstore parameters (Named constants defined by the Bookstore)
        private int hiddenAccessIDLength = 5;   // Length of AccessNet ID
        private int hiddenISBNLeftLength = 3;   // Length of left part of ISBN
        private int hiddenISBNRightLength = 3;  // Length of right part of ISBN
        // Number of attempts BookStore allows a user before terminating an inventory 
        //    update session
        private int hiddenTryCountMax = 3;
        string[] foundISBN = new string[6];
        private bool endOfFileReached = false;
        private int writtenCount = 0;
        private string bookString;
        int remainingCount;

        // Writes one book record to updated book file
        internal void writeOneRecord(string bookString)
        {
            writtenCount = 0;
            updatedBookFile.putNextRecord(bookString);//bookString >bookToPrint
            writtenCount++;
            copyRemainingRecords();
        }

        // Find Employee in Employee List
        // Returns a reference to the employee found and (through an argument) returns true or false
        public Employee findEmployee
            (int ID,              // IN: employee ID to be found   
             out Boolean found)   // OUT: flag indicating if Employee ID found in current Employee object
        {
            Employee emp = empList.FindEmployeeInList(ID);    // reference to current Employee being checked for ID

            if (emp != null)
            {
                found = true;
            }
            else
                found = false;
            return emp;
        }  // end findEmployee

        // Checks if ISBN already there
        public bool checkForDuplicateRecord(string isbn)
        {
            {
                if (book.checkISBN(isbn) == true) //checks isbn with hiddenISBN
                {
                    return true;
                }
            }
            return false;
        }

        // Takes a ISBN # from user and book record from file and sees if match, if match then split record into 6-parts and save
        public string[] findAndSaveBook(string isbn, string foundIsbn)
        {
            bool isEndOfFile = false;
            string[] foundISBN = new string[6];
            string bookString = "";
            currentBookFile.rewindFile();
            bookString = currentBookFile.getNextRecord(ref isEndOfFile);
            while (!isEndOfFile) // checks through file until book with matching isbn is found
            {
                 foundISBN = bookString.Split('*');
                 for (int i = 0; i < foundISBN.Length; i++)
                 {
                     foundISBN[i] = foundISBN[i].Trim();
                 }
                 if (isbn == foundISBN[0])
                 {
                     isEndOfFile = true;
                 }
                 else
                 {
                     updatedBookFile.putNextRecord(bookString);
                     bookString = currentBookFile.getNextRecord(ref isEndOfFile);
                 }
            }
            return foundISBN;
        }

        // Rewind external file sbefore closing
        public void rewindFiles()
        {
            currentBookFile.rewindFile();
            updatedBookFile.rewindFile();
        }  // end rewindFile

        // Prints out the updated employee into file
        public void writeEntireEmployeeList()
        {
            List<string> empListPrint = empList.writeEntireList(); 
                foreach (string s in empListPrint)
                {
                    updatedEmployeeFile.putNextRecord(s);
                }
            updatedEmployeeFile.closeFile();
        }
 
        // Updates a book record already existing
        public void updateBookFile(string bookString, string isbn)
        {
            writtenCount = 0;
            int whileCount = 0;
            string[] saveISBN = new string[6];
            bookString = "";
            currentBookFile.rewindFile();
            updatedBookFile.rewindFile();
            bookString = currentBookFile.getNextRecord(ref endOfFileReached);
            while (!endOfFileReached) // checks through file until book with matching isbn is found
            {
                saveISBN = bookString.Split('*');
                whileCount++;
                for (int i = 0; i < saveISBN.Length; i++)
                {
                    saveISBN[i] = saveISBN[i].Trim();
                }
                if (isbn == saveISBN[0])
                {
                    bookString = bookString;
                    endOfFileReached = true;
                    writtenCount++;
                }
                updatedBookFile.putNextRecord(bookString); 
                bookString = currentBookFile.getNextRecord(ref endOfFileReached);
                writtenCount++;
            }
        }

        // Adds book to book textfile
        public string[] addBookFile(string isbn)
        {
            writtenCount = 1;
            int whileCount = 0;
            string[] foundISBN = new string[6];
            bookString = "";
            currentBookFile.rewindFile();
            updatedBookFile.rewindFile();
            bookString = currentBookFile.getNextRecord(ref endOfFileReached);
            while (!endOfFileReached) // checks through file until book with matching isbn is found
            {
                foundISBN = bookString.Split('*');
                whileCount++;
                for (int i = 0; i < foundISBN.Length; i++)
                {
                    foundISBN[i] = foundISBN[i].Trim();
                }
                if (isbn == foundISBN[0])
                {
                    endOfFileReached = true;
                }
                if (bookString == null)
                {
                    break;
                }
                updatedBookFile.putNextRecord(bookString); 
                bookString = currentBookFile.getNextRecord(ref endOfFileReached);
                writtenCount++;
            }
            writtenCount++;
            return foundISBN;
        }

        // Read the files but don't write the matching isbn
        public void deleteBookFile(string isbn)
        {
            writtenCount = 0;
            string[] foundISBN = new string[6];
            bookString = "";
            currentBookFile.rewindFile();
            updatedBookFile.rewindFile();
            bookString = currentBookFile.getNextRecord(ref endOfFileReached);
            while (!endOfFileReached) // checks through file until book with matching isbn is found
            {
                bookString = currentBookFile.getNextRecord(ref endOfFileReached);
                foundISBN = bookString.Split('*');
                for (int i = 0; i < foundISBN.Length; i++)
                {
                    foundISBN[i] = foundISBN[i].Trim();
                }
                if (isbn == foundISBN[0])
                {
                    break;
                }
                endOfFileReached = true;
                writtenCount++;
            }
            writtenCount++;
        }

        // After employee changes made, copy remaining records in current file to updated file
        public void copyRemainingRecords() //break
        {
            remainingCount = 0;
            string bookString = "";
            Boolean endOfFile = false;
            bookString = currentBookFile.getNextRecord(ref endOfFile);
            while (!endOfFile) // checks through file until book with matching isbn is found
            {
                if (null == bookString)
                {
                    endOfFile = true;
                }
                else
                {
                    updatedBookFile.putNextRecord(bookString);
                    bookString = currentBookFile.getNextRecord(ref endOfFile);
                    remainingCount++;
                }
            }
        }

        // Gets number of written records
        public int getWrittenCount()
        {
            return writtenCount;
        }

        // Closes all files
        public void closeFiles()
        { 
            currentBookFile.closeFile();
            currentEmployeeFile.closeFile();
            updatedBookFile.closeFile();
            updatedEmployeeFile.closeFile();
        }

        // Returns book string to user
        public string[] bookStringToDisplay(string isbn)
        {
            bool isEndOfFile = false;
            foundISBN = new string[6];
            bookString = "";
            currentBookFile.rewindFile();
            bookString = currentBookFile.getNextRecord(ref isEndOfFile);
            while (!isEndOfFile) // checks through file until book with matching isbn is found
            {
                foundISBN = bookString.Split('*');
                for (int i = 0; i < foundISBN.Length; i++)
                {
                    foundISBN[i] = foundISBN[i].Trim();
                }
                if (isbn == foundISBN[0])
                {
                    isEndOfFile = true;
                }
                else
                {
                    bookString = currentBookFile.getNextRecord(ref isEndOfFile);
                }
            }
            return foundISBN;
        }

    }
}