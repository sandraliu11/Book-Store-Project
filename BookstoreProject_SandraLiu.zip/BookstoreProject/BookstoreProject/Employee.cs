﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: Creates employee object to be used to allow employees to log into system with ID and PIN # and contains methods to search through employee record
namespace BookstoreProject
{
    class Employee
    {
        int validAccessIDLength = 5;
        int validPinLength = 4;
        private int hiddenAccessID;
        private int hiddenPin;
        private string hiddenName;
        private decimal hiddenAnnualPay;
        private DateTime hiddenLastDateOfAccess;
        public EmployeeList empList = new EmployeeList();

        // constructor for employee (created in createEmployeeObject() instead and called in form load)
        public Employee()
        {
            // initializes employee object
        }

        public Boolean createEmployeeObject(string s)  // IN: string from the Employee Text File
        {
            Employee thisEmployee = this;
            string[] employeeString = s.Split('*');
            int i;

            int employeeStringSize = employeeString.GetLength(0);
            if (employeeString[0].Length != validAccessIDLength)
            {
                MessageBox.Show(employeeString[0]
                    + ": AccessID string is not exactly 5 characters. Employee File Corrupt. Execution Terminated.",
                      "AccessID in Employee File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            try
            {
                hiddenAccessID = Convert.ToInt32(employeeString[0]);
            }
            catch
            {
                MessageBox.Show(employeeString[0]
                    + " AccessID string is not a valid integer. Employee File Corrupt. Execution Terminated.",
                      "AccessID in Employee File Invalid",
                       MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            // Name string to string (no conversion)
            hiddenName = employeeString[1];
            if (hiddenName == " " || hiddenName == "")
            {
                MessageBox.Show(hiddenName
                    + ": Name string is empty or Blank. Employee File Corrupt. Execution Terminated.",
                      "Name in Employee File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            // Convert Pin to an integer of required length
            if (employeeString[2].Length != validPinLength)
            {
                MessageBox.Show(employeeString[2]
                    + ": Pin string is not exactly 4 characters. Employee File Corrupt. Execution Terminated.",
                      "Pin in Employee File Invalid", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            try
            {
                hiddenPin = Convert.ToInt32(employeeString[2]);
            }
            catch
            {
                MessageBox.Show(employeeString[2]
                    + ": Pin string is empty or Blank. Employee File Corrupt.  Execution Terminated.",
                      "Pin in Employee File Invalid", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            // Convert annualPay to a positive decimal
            try
            {
                hiddenAnnualPay = Convert.ToDecimal(employeeString[3].Replace(",",
                    "").Replace("$", ""));
            }
            catch
            {
                MessageBox.Show(employeeString[3]
                    + ": Annual Pay string is not a valid decimal. Employee File Corrupt. Execution Terminated.",
                      "Annual pay in Employee File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            // Convert last Date of Access to a date
            try
            {
                hiddenLastDateOfAccess = DateTime.Parse(employeeString[4]);
            }
            catch
            {
                MessageBox.Show(employeeString[4]
                    + ": Date of Last Access string is not a valid date. Employee File Corrupt.  Execution Terminated.",
                      "Date of last access in Employee File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
            // All data valid
            return (true);
        }  // end createEmployeeObject

        //Verifies employee PIN
        public bool checkPIN(int pin) 
        {
            Employee emp = this;
            if (emp.hiddenPin == pin)
            {
                return true;
            }
            return false;
        }

        //Updates last employee transaction date
        public DateTime updateEmployeeTransactionDate(DateTime date)
        {
            date = DateTime.Today;
            return date;
        }

        //Display records in printable format; employee list gives index 
        public string createStringToDisplay()
        {
            hiddenLastDateOfAccess = updateEmployeeTransactionDate(hiddenLastDateOfAccess);
            string displayedString = ("ID: " + hiddenAccessID + "\r\nPIN: " + hiddenPin +
                "\r\nName: " + hiddenName + "\r\nAnnual Pay: " + hiddenAnnualPay +
                "\r\nLast date of access: " + hiddenLastDateOfAccess);
            return displayedString;
        }

        // Displays the list of employees (After they were written to the Employee File)
        public string writeEntireEmployeeList()
        {
            string toPrintString = (hiddenAccessID + "*" + hiddenPin +
                "*" + hiddenName + "*" + hiddenAnnualPay +
                "*" + hiddenLastDateOfAccess);
            return toPrintString;
        }  

        // Gets employee access ID
        public int GetAccessID()
        {
            return (Convert.ToInt32(hiddenAccessID));
        }
    }
}
