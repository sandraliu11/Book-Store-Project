﻿namespace BookstoreProject
{
    partial class frmEmployeeAccessIDEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblBookWorm = new System.Windows.Forms.Label();
            this.lblBookStore = new System.Windows.Forms.Label();
            this.lblEnterAccessID = new System.Windows.Forms.Label();
            this.txtEnterAccessID = new System.Windows.Forms.TextBox();
            this.btnFindMe = new System.Windows.Forms.Button();
            this.picBookstore = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picBookstore)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Pristina", 21.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(172, 87);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(286, 67);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome to the";
            // 
            // lblBookWorm
            // 
            this.lblBookWorm.AutoSize = true;
            this.lblBookWorm.Font = new System.Drawing.Font("Pristina", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookWorm.Location = new System.Drawing.Point(52, 178);
            this.lblBookWorm.Name = "lblBookWorm";
            this.lblBookWorm.Size = new System.Drawing.Size(535, 147);
            this.lblBookWorm.TabIndex = 1;
            this.lblBookWorm.Text = "Book Worm";
            // 
            // lblBookStore
            // 
            this.lblBookStore.AutoSize = true;
            this.lblBookStore.Font = new System.Drawing.Font("Pristina", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookStore.Location = new System.Drawing.Point(76, 314);
            this.lblBookStore.Name = "lblBookStore";
            this.lblBookStore.Size = new System.Drawing.Size(472, 147);
            this.lblBookStore.TabIndex = 2;
            this.lblBookStore.Text = "Book Store";
            // 
            // lblEnterAccessID
            // 
            this.lblEnterAccessID.AutoSize = true;
            this.lblEnterAccessID.Font = new System.Drawing.Font("Modern No. 20", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterAccessID.Location = new System.Drawing.Point(153, 546);
            this.lblEnterAccessID.Name = "lblEnterAccessID";
            this.lblEnterAccessID.Size = new System.Drawing.Size(801, 35);
            this.lblEnterAccessID.TabIndex = 3;
            this.lblEnterAccessID.Text = "Enter your 5-digit Access ID below, then click \"Find Me\".";
            // 
            // txtEnterAccessID
            // 
            this.txtEnterAccessID.Location = new System.Drawing.Point(184, 656);
            this.txtEnterAccessID.Name = "txtEnterAccessID";
            this.txtEnterAccessID.Size = new System.Drawing.Size(142, 29);
            this.txtEnterAccessID.TabIndex = 4;
            // 
            // btnFindMe
            // 
            this.btnFindMe.Font = new System.Drawing.Font("Modern No. 20", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindMe.Location = new System.Drawing.Point(393, 644);
            this.btnFindMe.Name = "btnFindMe";
            this.btnFindMe.Size = new System.Drawing.Size(194, 49);
            this.btnFindMe.TabIndex = 5;
            this.btnFindMe.Text = "Find Me!";
            this.btnFindMe.UseVisualStyleBackColor = true;
            this.btnFindMe.Click += new System.EventHandler(this.btnFindMe_Click);
            // 
            // picBookstore
            // 
            this.picBookstore.Image = global::BookstoreProject.Properties.Resources.dreams_metroeve_book_store_dreams_meaning;
            this.picBookstore.Location = new System.Drawing.Point(607, 87);
            this.picBookstore.Name = "picBookstore";
            this.picBookstore.Size = new System.Drawing.Size(497, 374);
            this.picBookstore.TabIndex = 6;
            this.picBookstore.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Modern No. 20", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(796, 644);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(191, 49);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmEmployeeAccessIDEntry
            // 
            this.AcceptButton = this.btnFindMe;
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(1182, 787);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.picBookstore);
            this.Controls.Add(this.btnFindMe);
            this.Controls.Add(this.txtEnterAccessID);
            this.Controls.Add(this.lblEnterAccessID);
            this.Controls.Add(this.lblBookStore);
            this.Controls.Add(this.lblBookWorm);
            this.Controls.Add(this.lblWelcome);
            this.Name = "frmEmployeeAccessIDEntry";
            this.Text = "Employee Access ID Entry";
            this.Load += new System.EventHandler(this.frmEmployeeAccessIDEntry_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBookstore)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblBookWorm;
        private System.Windows.Forms.Label lblBookStore;
        private System.Windows.Forms.Label lblEnterAccessID;
        private System.Windows.Forms.TextBox txtEnterAccessID;
        private System.Windows.Forms.Button btnFindMe;
        private System.Windows.Forms.PictureBox picBookstore;
        private System.Windows.Forms.Button btnExit;
    }
}

