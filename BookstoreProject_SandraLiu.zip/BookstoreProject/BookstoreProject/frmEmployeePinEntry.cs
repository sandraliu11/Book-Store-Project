﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: Form for user entering their matching PIN number
namespace BookstoreProject
{
    public partial class frmEmployeePinEntry : Form
    {
        public frmEmployeePinEntry()
        {
            InitializeComponent();
        }

        // Declares all objects of this Form class
        string employeePINString;
        int employeePIN;
        bool foundPIN;
        private int wrongPINCount = 0;

        // Validates pin entered and checks if pin matches the found pin at the saved employee index
        private void btnOk_Click(object sender, EventArgs e)
        {
            txtEnterPin.Focus();
            // Gives values to employee access ID 
            employeePINString = txtEnterPin.Text;
            //Validates access ID length and makes sure no letters
            if (employeePINString.Length != 4 || ValidatePIN() == false)
            {
                MessageBox.Show("Your PIN must be a 4-digit number. Please Re-enter.");
                txtEnterPin.Clear();
                txtEnterPin.Focus();
                wrongPINCount++; // Increment wrong entry count if entered wrong
                if (wrongPINCount == 3)
                {
                    MessageBox.Show("You have reached the maximum number of wrong Access ID entries. Exiting program.",
                            "Maximum PIN Entries Reached", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    this.Close();
                }
            }
            else
            {
                // Use index of employee access ID to find the matching PIN number 
                employeePIN = Convert.ToInt32(employeePINString);
                // Get value of found PIN by verifying PIN 
                foundPIN = Globals.BookStore.empList.verifyPIN(employeePIN);

                if (foundPIN == false) // if PIN at index does not match entered PIN then tell user id not found
                {
                    MessageBox.Show("Your PIN did not match your Access ID. Please re-enter.");
                    wrongPINCount++; // Increment wrong entry count if entered wrong
                    txtEnterPin.Clear();
                    txtEnterPin.Focus();
                    if (wrongPINCount == 3)
                    {
                        MessageBox.Show("You have reached the maximum number of wrong PIN entries. Exiting program.",
                            "Maximum PIN Entries Reached", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        this.Close();
                    }
                }
                else if (foundPIN == true) // if PIN at index matches entered PIN then go form 3
                {
                    // Displays to user current employee record with updated date
                    MessageBox.Show(Globals.BookStore.empList.displayEmployeeRecord());
                    Globals.BookStore.writeEntireEmployeeList();
                    if (Globals.BookStore.empList.writeEntireList() != null)
                    {
                        MessageBox.Show("Employee record has been written to updated employee file.");
                    }
                    //Shows to user which employee ID is found for verification purposes
                    //Goes to next form and closes this current form
                    this.Hide();
                    var form2 = new frmTransactionSelect();
                    form2.Closed += (s, args) => this.Close();
                    form2.Show();
                }
            }
        }

        // Exits form and closes files
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            // Closes all files
            Globals.BookStore.closeFiles();
        }

        // Validates pin is digits only
        private bool ValidatePIN()
        {
            int val;
            if (int.TryParse(txtEnterPin.Text, out val))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
