﻿namespace BookstoreProject
{
    partial class frmEmployeePinEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookStore = new System.Windows.Forms.Label();
            this.lblBookWorm = new System.Windows.Forms.Label();
            this.lblPinEntryForm = new System.Windows.Forms.Label();
            this.lblEnterPin = new System.Windows.Forms.Label();
            this.txtEnterPin = new System.Windows.Forms.TextBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBookStore
            // 
            this.lblBookStore.AutoSize = true;
            this.lblBookStore.Font = new System.Drawing.Font("Pristina", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookStore.Location = new System.Drawing.Point(608, 74);
            this.lblBookStore.Name = "lblBookStore";
            this.lblBookStore.Size = new System.Drawing.Size(472, 147);
            this.lblBookStore.TabIndex = 5;
            this.lblBookStore.Text = "Book Store";
            // 
            // lblBookWorm
            // 
            this.lblBookWorm.AutoSize = true;
            this.lblBookWorm.Font = new System.Drawing.Font("Pristina", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookWorm.Location = new System.Drawing.Point(109, 74);
            this.lblBookWorm.Name = "lblBookWorm";
            this.lblBookWorm.Size = new System.Drawing.Size(535, 147);
            this.lblBookWorm.TabIndex = 4;
            this.lblBookWorm.Text = "Book Worm";
            // 
            // lblPinEntryForm
            // 
            this.lblPinEntryForm.AutoSize = true;
            this.lblPinEntryForm.Font = new System.Drawing.Font("Perpetua", 21.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPinEntryForm.Location = new System.Drawing.Point(432, 204);
            this.lblPinEntryForm.Name = "lblPinEntryForm";
            this.lblPinEntryForm.Size = new System.Drawing.Size(362, 59);
            this.lblPinEntryForm.TabIndex = 6;
            this.lblPinEntryForm.Text = "PIN Entry Form";
            // 
            // lblEnterPin
            // 
            this.lblEnterPin.AutoSize = true;
            this.lblEnterPin.Font = new System.Drawing.Font("Modern No. 20", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterPin.Location = new System.Drawing.Point(128, 466);
            this.lblEnterPin.Name = "lblEnterPin";
            this.lblEnterPin.Size = new System.Drawing.Size(666, 35);
            this.lblEnterPin.TabIndex = 7;
            this.lblEnterPin.Text = "Enter your 4-digit PIN number and press \"OK\".";
            // 
            // txtEnterPin
            // 
            this.txtEnterPin.Location = new System.Drawing.Point(838, 471);
            this.txtEnterPin.Name = "txtEnterPin";
            this.txtEnterPin.Size = new System.Drawing.Size(136, 29);
            this.txtEnterPin.TabIndex = 8;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(408, 587);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(121, 54);
            this.btnOk.TabIndex = 9;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(633, 587);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(115, 54);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmEmployeePinEntry
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(1182, 787);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.txtEnterPin);
            this.Controls.Add(this.lblEnterPin);
            this.Controls.Add(this.lblPinEntryForm);
            this.Controls.Add(this.lblBookStore);
            this.Controls.Add(this.lblBookWorm);
            this.Name = "frmEmployeePinEntry";
            this.Text = "frmEmployeePinEntry";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookStore;
        private System.Windows.Forms.Label lblBookWorm;
        private System.Windows.Forms.Label lblPinEntryForm;
        private System.Windows.Forms.Label lblEnterPin;
        private System.Windows.Forms.TextBox txtEnterPin;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnExit;
    }
}