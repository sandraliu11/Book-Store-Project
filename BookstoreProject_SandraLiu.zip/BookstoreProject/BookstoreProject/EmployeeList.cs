﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: Contains method for initializing employee list and is in charge of all methods dealing with the employee list data manipulation

namespace BookstoreProject
{
    class EmployeeList
    {
        //Declares and instantiates employee type and current file type list
        List<Employee> empList = new List<Employee>(1000); // THIS IS WHERE ALL EMPLOYEE OBJECTS ARE STORED
        int enteredID = 0;
        int count = 0;
        int index = 0;

        // Constructor of employee list object type (called in form load (1) and initialized with initializeEntireList() method)
        public EmployeeList()
        {
            //initializeEntireList();
        }

        // initializes list of employees from file
        public Boolean initializeEntireList()
        {
            Employee emp;
            // Declares all objects of the method
            string nextRecord;
            Boolean isEndOfFile = true;
            Boolean success;
            int countProcessedRecords = 0;
            nextRecord = BookStore.currentEmployeeFile.getNextRecord(ref isEndOfFile);

            while (!isEndOfFile)
            {
                countProcessedRecords++;
                emp = new Employee();
                success = emp.createEmployeeObject(nextRecord);
                if (success != true)
                {
                    MessageBox.Show
                       ("Unable to create an Employee Object.  Employee list not created.",
                        "Employee List Creation Failed", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }
                empList.Add(emp);
                nextRecord = BookStore.currentEmployeeFile.getNextRecord(ref isEndOfFile);
            } //end While

            if (countProcessedRecords > 0)
                return true;
            else
                return false;
        }  // end initializeEntireList

        //Find employee in employee list with access ID entered
        public Employee FindEmployeeInList(int enteredID)
        {
            int employeeID;
            foreach (Employee e in empList) // Tommy Tran's Code
            {
                // For each employee, take access ID out of each and compare to entered ID
                employeeID = (int)e.GetAccessID(); //breakpoint
                // Compare entered ID with ID on employee list
                if (employeeID == enteredID) //breakpoint
                {
                    index = count;
                    return e;
                }
                else if (employeeID != enteredID) // if test failed
                {
                    count++;
                    if (count > 4)
                    {
                        count = 0;
                    }
                }
            }
            return null;
        }

        // Takes employee list data in w/ createStringToDisplay() by matching index to print specific employee data 
        internal string displayEmployeeRecord()
        {
            return empList[index].createStringToDisplay();
        }

        // Write entire employee list to updatedEmployeeFile obj
        public List<string> writeEntireList()
        {
            //System.IO.File.WriteAllLines("C:\\Users\\Sandra Liu\\Documents\\BookstoreProject\\BookstoreProject\\updatedEmployeeFile.txt", empList[]);
            //return true;
            //Employee.writeEntireEmployeeList();
            //List<string> employeeString = new List<string>();
            List<string> employeeString = new List<string>();
            string foundEmployeeString = empList[index].writeEntireEmployeeList();
            //employeeString.Add(foundEmployeeString);

            foreach (Employee e in empList)
            {
                string printString = e.writeEntireEmployeeList();
                employeeString.Add(printString);
                /*if (e != empList[index])
                {
                    employeeString.Add(printString);
                    /*for (int i=0; i<=4; i++)
                    {
                        string remainingEmp = Convert.ToString(empList[index + i]);
                        employeeString.Add(remainingEmp);
                    }
                    //write to text file
                }
                else if (e == empList[index])
                {
                    if (index < empList.Count)
                    employeeString.Add(foundEmployeeString);
                    employeeString.Add(printString);
                    //update date of access
                    //write to file
                    break;
                }*/
                //return employeeString;
            }
            return employeeString;
            //UpdatedFile newFile = UpdatedFile
        }

        // Verifies that pin entered matches the employee on record
        public bool verifyPIN(int enteredPIN)
        {
            //Employee emp = new Employee();
            //int pin;
            //Employee foundEmployee = empList[index];
            if (empList[index].checkPIN(enteredPIN)) 
                {
                    return true;
                }
                else
                {
                    return false;
                }
        }

        // Gets index where entered access ID matches employee record
        public int getIndex()
        {
            return index;
        }

        // Gets count of # of employee records
        public int getCount()
        {
            return count;
        }

        // Sets the index of found employee id to be used to find pin
        public int setIndex(int ID)
        {
            foreach (Employee e in empList)
            {
                int employeeID = (int)e.GetAccessID();
                for (int i = 0; i <= 5; i++)
                {
                    if (employeeID == ID)
                    {
                        index = Convert.ToInt32(empList[i]);
                        getIndex();
                        return index;
                    }
                } 
            }
            return 0;
        }

    }
}
