﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: Form for entering user access ID
namespace BookstoreProject
{
    public partial class frmEmployeeAccessIDEntry : Form
    {
        Employee emp;
        //Declares employee, access ID, and boolean for access ID patch found
        string employeeAccessIDString;
        int employeeAccessID;
        private bool accessIDPatchFound;
        private int wrongAccessIDCount = 0;

        public frmEmployeeAccessIDEntry()
        {
            InitializeComponent();
        }

        // Checks if entered access ID is on file and saves index to move onto form 2
        private void btnFindMe_Click(object sender, EventArgs e)
        {
            txtEnterAccessID.Focus();
            employeeAccessIDString = txtEnterAccessID.Text; // Gives values to employee access ID 

            //Validates access ID length and makes sure no letters
            if (employeeAccessIDString.Length != 5 || ValidateAccessID() == false)
            {
                MessageBox.Show("Your access ID must be a 5-digit number. Please Re-enter.");
                txtEnterAccessID.Clear();
                txtEnterAccessID.Focus();
                wrongAccessIDCount++; // Increment wrong entry count if entered wrong
                if (wrongAccessIDCount == 3)
                {
                    MessageBox.Show("You have reached the maximum number of wrong Access ID entries. Exiting program.",
                            "Maximum Access ID Entries Reached", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    this.Close();
                }
            }
            else
            {
                employeeAccessID = Convert.ToInt32(employeeAccessIDString);
                // Checks if employee ID is valid
                emp = Globals.BookStore.findEmployee(employeeAccessID, out accessIDPatchFound);
                if (accessIDPatchFound == false)
                {
                    MessageBox.Show("Your access ID was not found. Please re-enter.");
                    wrongAccessIDCount++; // Increment wrong entry count if entered wrong
                    txtEnterAccessID.Clear();
                    txtEnterAccessID.Focus();
                    if (wrongAccessIDCount == 3)
                    {
                        MessageBox.Show("You have reached the maximum number of wrong Access ID entries. Exiting program.");
                        this.Close();
                    }
                }
                else if (accessIDPatchFound == true)
                {
                    //Goes to next form and closes this current form
                    this.Hide();
                    var form2 = new frmEmployeePinEntry();
                    form2.Closed += (s, args) => this.Close();
                    form2.Show();
                }
            }
        }

        // Validates access ID to make sure digits only
        private bool ValidateAccessID()
        {
            int val;
            if (int.TryParse(txtEnterAccessID.Text, out val))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Exits form and closes files
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            // Closes all files
            Globals.BookStore.closeFiles();
        }

        // Initializes employee list in form load
        private void frmEmployeeAccessIDEntry_Load(object sender, EventArgs e)
        {
            Globals.BookStore.empList.initializeEntireList();
        }
    }
}
