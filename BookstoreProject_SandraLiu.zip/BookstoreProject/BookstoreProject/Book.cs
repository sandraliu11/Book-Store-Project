﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: Creates book string object so user can parse through, contains methods to parse through to get each book attribute to user

namespace BookstoreProject
{
    class Book
    {
        bool isEndOfFile = false;
        int validISBNLength = 6;
        private string hiddenISBN;
        private string hiddenTitle;
        private string hiddenAuthor;
        private decimal hiddenPrice;
        private int hiddenOnHand;
        private DateTime hiddenTransactionDate;
        string bookInfoString;
        private int countProcessedRecords;
        string[] book = new string[6];
        string displayedBookString = "";

        public Book()
        {
            // initializes book object
        }

        // creates book object for bookStore to iterate through 
        public String createBookObject(string s)  // IN: string from the Book Text File
        {
            Book thisBook = this;
            string[] bookString = s.Split('*');
            int bookStringSize = bookString.GetLength(0);
            hiddenISBN = bookString[0];
            // Convert ISBN to an integer of required length
            if (bookString[0].Length != validISBNLength)
            {
                MessageBox.Show(bookString[0]
                    + ": ISBN string is not exactly 6 characters. Book File Corrupt. Execution Terminated.",
                      "ISBN in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            try
            {
                hiddenISBN = bookString[0];
            }
            catch
            {
                MessageBox.Show(bookString[0]
                    + " ISBN string is not a valid integer. Book File Corrupt. Execution Terminated.",
                      "ISBN in Book File Invalid",
                       MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            // Title string to string (no conversion)
            hiddenTitle = bookString[1];
            if (hiddenTitle == " " || hiddenTitle == "")
            {
                MessageBox.Show(hiddenTitle
                    + ": Title string is empty or Blank. Book File Corrupt. Execution Terminated.",
                      "Title in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            // Author string to string (no conversion)
            hiddenAuthor = bookString[2];
            if (hiddenAuthor == " " || hiddenAuthor == "")
            {
                MessageBox.Show(hiddenAuthor
                    + ": Author string is empty or Blank. Book File Corrupt. Execution Terminated.",
                      "Author in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            // Convert book price to a positive decimal
            try
            {
                hiddenPrice = Convert.ToDecimal(bookString[3].Replace(",",
                    "").Replace("$", ""));
            }
            catch
            {
                MessageBox.Show(bookString[3]
                    + ": Price string is not a valid decimal. Book File Corrupt. Execution Terminated.",
                      "Price in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            // Convert On Hand # to an integer of required length
            if (bookString[4].Length == 0)
            {
                MessageBox.Show(bookString[4]
                    + ": # On Hand string is not exactly 4 characters. Book File Corrupt. Execution Terminated.",
                      "# On Hand in Book File Invalid", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            try
            {
                hiddenOnHand = Convert.ToInt32(bookString[4]);
            }
            catch
            {
                MessageBox.Show(bookString[4]
                    + ": # On Hand string is empty or Blank. Book File Corrupt.  Execution Terminated.",
                      "# On Hand in Book File Invalid", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            // Convert transaction date to a date
            try
            {
                hiddenTransactionDate = DateTime.Parse(bookString[5]);
            }
            catch
            {
                MessageBox.Show(bookString[5]
                    + ": Transaction date string is not a valid date. Book File Corrupt.  Execution Terminated.",
                      "Transaction date in Book File Invalid",
                      MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            bookInfoString = Convert.ToString(bookString);
            return bookInfoString;
        }  // end createBookObject

        //Display book records in printable format; book list gives index 
        public string createStringToDisplay(string isbn)
        {
            if (isbn == hiddenISBN)
            { 
                displayedBookString = ("ISBN: " + hiddenISBN + "\r\nTitle: " + hiddenTitle +
                    "\r\nAuthor: " + hiddenAuthor + "\r\nPrice: " + hiddenPrice + "\r\nOn Hand: " + hiddenOnHand +
                    "\r\nTransaction Date: " + hiddenTransactionDate);
            }
            return displayedBookString;
        }

        //Display book record to show user; book list gives index 
        public string[] createStringForForm(string isbnPart1, string isbnPart2)
        {
            if (book[0] == (isbnPart1 + isbnPart2))
            {
                return book;
            }
            return book;
        }

        //Verifies Book ISBN
        public bool checkISBN(string isbn) // return 
        {
            book = Globals.BookStore.findAndSaveBook(isbn, hiddenISBN);
            if (book[0] == isbn)
            {
                return true;
            }
            return false;
        }

        /*public void readBook()
        {
            string nextRecord;
            nextRecord = BookStore.currentBookFile.getNextRecord(ref isEndOfFile);
            while (!isEndOfFile)
            {
                countProcessedRecords++;
                Book book = new Book();
                //string successString = book.createStringToDisplay(ISBN);
                if (successString == null)
                {
                    MessageBox.Show
                       ("Unable to create an Book Object.",
                        "Book Object Not Created", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                //empList.Add(emp);
                nextRecord = BookStore.currentBookFile.getNextRecord(ref isEndOfFile);
            } //end While

            //if (countProcessedRecords > 0)
                //return true;
            //else
                //return false;
        }*/

        // Displays the list of books (After they were written to the Book File)
        public string writeEntireBookList()
        {
            string toPrintBookString = (hiddenISBN + "*" + hiddenTitle +
                "*" + hiddenAuthor + "*" + hiddenPrice + "*" + hiddenOnHand +
                "*" + hiddenTransactionDate);
            return toPrintBookString;
        }   // end writeEntireBookList
    }
}
