﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
//Sandra Liu
// CIS 3309 Spring 2018
// March 14, 2018
// Class purpose: Main entry point for application
namespace BookstoreProject
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmEmployeeAccessIDEntry());
        }
    }
}
