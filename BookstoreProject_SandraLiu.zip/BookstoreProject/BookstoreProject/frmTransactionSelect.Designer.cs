﻿namespace BookstoreProject
{
    partial class frmTransactionSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookStore = new System.Windows.Forms.Label();
            this.lblBookWorm = new System.Windows.Forms.Label();
            this.lblTransactionPage = new System.Windows.Forms.Label();
            this.lblEnterISBN = new System.Windows.Forms.Label();
            this.lblSelectTransaction = new System.Windows.Forms.Label();
            this.btnAddNewBook = new System.Windows.Forms.Button();
            this.btnUpdateBook = new System.Windows.Forms.Button();
            this.btnDeleteBook = new System.Windows.Forms.Button();
            this.txtISBN1 = new System.Windows.Forms.TextBox();
            this.txtISBN2 = new System.Windows.Forms.TextBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.grpInventoryChangeControls = new System.Windows.Forms.GroupBox();
            this.btnNo = new System.Windows.Forms.Button();
            this.btnYes = new System.Windows.Forms.Button();
            this.txtTransactionDate = new System.Windows.Forms.TextBox();
            this.txtOnHand = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.lblTransactionDate = new System.Windows.Forms.Label();
            this.lblOnHand = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblISBN = new System.Windows.Forms.Label();
            this.lblEnterData = new System.Windows.Forms.Label();
            this.lblISBNDash = new System.Windows.Forms.Label();
            this.btnDoneAdd = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnDoneUpdate = new System.Windows.Forms.Button();
            this.grpInventoryChangeControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBookStore
            // 
            this.lblBookStore.AutoSize = true;
            this.lblBookStore.Font = new System.Drawing.Font("Pristina", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookStore.Location = new System.Drawing.Point(559, 9);
            this.lblBookStore.Name = "lblBookStore";
            this.lblBookStore.Size = new System.Drawing.Size(247, 75);
            this.lblBookStore.TabIndex = 7;
            this.lblBookStore.Text = "Book Store";
            // 
            // lblBookWorm
            // 
            this.lblBookWorm.AutoSize = true;
            this.lblBookWorm.Font = new System.Drawing.Font("Pristina", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookWorm.Location = new System.Drawing.Point(304, 9);
            this.lblBookWorm.Name = "lblBookWorm";
            this.lblBookWorm.Size = new System.Drawing.Size(276, 75);
            this.lblBookWorm.TabIndex = 6;
            this.lblBookWorm.Text = "Book Worm";
            // 
            // lblTransactionPage
            // 
            this.lblTransactionPage.AutoSize = true;
            this.lblTransactionPage.Font = new System.Drawing.Font("Modern No. 20", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransactionPage.Location = new System.Drawing.Point(433, 84);
            this.lblTransactionPage.Name = "lblTransactionPage";
            this.lblTransactionPage.Size = new System.Drawing.Size(254, 35);
            this.lblTransactionPage.TabIndex = 8;
            this.lblTransactionPage.Text = "Transaction Page";
            // 
            // lblEnterISBN
            // 
            this.lblEnterISBN.AutoSize = true;
            this.lblEnterISBN.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterISBN.Location = new System.Drawing.Point(44, 135);
            this.lblEnterISBN.Name = "lblEnterISBN";
            this.lblEnterISBN.Size = new System.Drawing.Size(643, 35);
            this.lblEnterISBN.TabIndex = 9;
            this.lblEnterISBN.Text = "Enter the ISBN for book (format: nnn-nnn):";
            // 
            // lblSelectTransaction
            // 
            this.lblSelectTransaction.AutoSize = true;
            this.lblSelectTransaction.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectTransaction.Location = new System.Drawing.Point(152, 207);
            this.lblSelectTransaction.Name = "lblSelectTransaction";
            this.lblSelectTransaction.Size = new System.Drawing.Size(259, 29);
            this.lblSelectTransaction.TabIndex = 10;
            this.lblSelectTransaction.Text = "Select a transaction:";
            // 
            // btnAddNewBook
            // 
            this.btnAddNewBook.Location = new System.Drawing.Point(511, 207);
            this.btnAddNewBook.Name = "btnAddNewBook";
            this.btnAddNewBook.Size = new System.Drawing.Size(430, 41);
            this.btnAddNewBook.TabIndex = 11;
            this.btnAddNewBook.Text = "Add new book to inventory";
            this.btnAddNewBook.UseVisualStyleBackColor = true;
            this.btnAddNewBook.Click += new System.EventHandler(this.btnAddNewBook_Click);
            // 
            // btnUpdateBook
            // 
            this.btnUpdateBook.Location = new System.Drawing.Point(511, 266);
            this.btnUpdateBook.Name = "btnUpdateBook";
            this.btnUpdateBook.Size = new System.Drawing.Size(430, 40);
            this.btnUpdateBook.TabIndex = 12;
            this.btnUpdateBook.Text = "Update book in inventory";
            this.btnUpdateBook.UseVisualStyleBackColor = true;
            this.btnUpdateBook.Click += new System.EventHandler(this.btnUpdateBook_Click);
            // 
            // btnDeleteBook
            // 
            this.btnDeleteBook.Location = new System.Drawing.Point(511, 326);
            this.btnDeleteBook.Name = "btnDeleteBook";
            this.btnDeleteBook.Size = new System.Drawing.Size(430, 43);
            this.btnDeleteBook.TabIndex = 13;
            this.btnDeleteBook.Text = "Delete book from inventory";
            this.btnDeleteBook.UseVisualStyleBackColor = true;
            this.btnDeleteBook.Click += new System.EventHandler(this.btnDeleteBook_Click);
            // 
            // txtISBN1
            // 
            this.txtISBN1.Location = new System.Drawing.Point(710, 142);
            this.txtISBN1.Name = "txtISBN1";
            this.txtISBN1.Size = new System.Drawing.Size(100, 29);
            this.txtISBN1.TabIndex = 14;
            this.txtISBN1.TextChanged += new System.EventHandler(this.txtISBN1_TextChanged);
            // 
            // txtISBN2
            // 
            this.txtISBN2.Location = new System.Drawing.Point(841, 143);
            this.txtISBN2.Name = "txtISBN2";
            this.txtISBN2.Size = new System.Drawing.Size(100, 29);
            this.txtISBN2.TabIndex = 15;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(983, 135);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 47);
            this.btnOk.TabIndex = 16;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // grpInventoryChangeControls
            // 
            this.grpInventoryChangeControls.Controls.Add(this.btnNo);
            this.grpInventoryChangeControls.Controls.Add(this.btnYes);
            this.grpInventoryChangeControls.Controls.Add(this.txtTransactionDate);
            this.grpInventoryChangeControls.Controls.Add(this.txtOnHand);
            this.grpInventoryChangeControls.Controls.Add(this.txtPrice);
            this.grpInventoryChangeControls.Controls.Add(this.txtAuthor);
            this.grpInventoryChangeControls.Controls.Add(this.txtTitle);
            this.grpInventoryChangeControls.Controls.Add(this.txtISBN);
            this.grpInventoryChangeControls.Controls.Add(this.lblTransactionDate);
            this.grpInventoryChangeControls.Controls.Add(this.lblOnHand);
            this.grpInventoryChangeControls.Controls.Add(this.lblPrice);
            this.grpInventoryChangeControls.Controls.Add(this.lblAuthor);
            this.grpInventoryChangeControls.Controls.Add(this.lblTitle);
            this.grpInventoryChangeControls.Controls.Add(this.lblISBN);
            this.grpInventoryChangeControls.Controls.Add(this.lblEnterData);
            this.grpInventoryChangeControls.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpInventoryChangeControls.Location = new System.Drawing.Point(26, 398);
            this.grpInventoryChangeControls.Name = "grpInventoryChangeControls";
            this.grpInventoryChangeControls.Size = new System.Drawing.Size(1067, 248);
            this.grpInventoryChangeControls.TabIndex = 17;
            this.grpInventoryChangeControls.TabStop = false;
            this.grpInventoryChangeControls.Text = "Book Inventory Change Controls";
            // 
            // btnNo
            // 
            this.btnNo.Location = new System.Drawing.Point(892, 20);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(106, 49);
            this.btnNo.TabIndex = 14;
            this.btnNo.Text = "No";
            this.btnNo.UseVisualStyleBackColor = true;
            this.btnNo.Click += new System.EventHandler(this.btnNo_Click);
            // 
            // btnYes
            // 
            this.btnYes.Location = new System.Drawing.Point(741, 20);
            this.btnYes.Name = "btnYes";
            this.btnYes.Size = new System.Drawing.Size(101, 49);
            this.btnYes.TabIndex = 13;
            this.btnYes.Text = "Yes";
            this.btnYes.UseVisualStyleBackColor = true;
            this.btnYes.Click += new System.EventHandler(this.btnYes_Click);
            // 
            // txtTransactionDate
            // 
            this.txtTransactionDate.Location = new System.Drawing.Point(785, 188);
            this.txtTransactionDate.Name = "txtTransactionDate";
            this.txtTransactionDate.Size = new System.Drawing.Size(178, 35);
            this.txtTransactionDate.TabIndex = 12;
            // 
            // txtOnHand
            // 
            this.txtOnHand.Location = new System.Drawing.Point(785, 137);
            this.txtOnHand.Name = "txtOnHand";
            this.txtOnHand.Size = new System.Drawing.Size(178, 35);
            this.txtOnHand.TabIndex = 11;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(785, 87);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(178, 35);
            this.txtPrice.TabIndex = 10;
            // 
            // txtAuthor
            // 
            this.txtAuthor.Location = new System.Drawing.Point(201, 188);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(197, 35);
            this.txtAuthor.TabIndex = 9;
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(201, 137);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(197, 35);
            this.txtTitle.TabIndex = 8;
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(201, 87);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(197, 35);
            this.txtISBN.TabIndex = 7;
            // 
            // lblTransactionDate
            // 
            this.lblTransactionDate.AutoSize = true;
            this.lblTransactionDate.Location = new System.Drawing.Point(498, 188);
            this.lblTransactionDate.Name = "lblTransactionDate";
            this.lblTransactionDate.Size = new System.Drawing.Size(227, 29);
            this.lblTransactionDate.TabIndex = 6;
            this.lblTransactionDate.Text = "Transaction Date:";
            // 
            // lblOnHand
            // 
            this.lblOnHand.AutoSize = true;
            this.lblOnHand.Location = new System.Drawing.Point(599, 143);
            this.lblOnHand.Name = "lblOnHand";
            this.lblOnHand.Size = new System.Drawing.Size(136, 29);
            this.lblOnHand.TabIndex = 5;
            this.lblOnHand.Text = "On Hand: ";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(644, 93);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(81, 29);
            this.lblPrice.TabIndex = 4;
            this.lblPrice.Text = "Price:";
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Location = new System.Drawing.Point(35, 188);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(104, 29);
            this.lblAuthor.TabIndex = 3;
            this.lblAuthor.Text = "Author:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(65, 143);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(74, 29);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Title:";
            // 
            // lblISBN
            // 
            this.lblISBN.AutoSize = true;
            this.lblISBN.Location = new System.Drawing.Point(55, 93);
            this.lblISBN.Name = "lblISBN";
            this.lblISBN.Size = new System.Drawing.Size(84, 29);
            this.lblISBN.TabIndex = 1;
            this.lblISBN.Text = "ISBN:";
            // 
            // lblEnterData
            // 
            this.lblEnterData.AutoSize = true;
            this.lblEnterData.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterData.Location = new System.Drawing.Point(19, 43);
            this.lblEnterData.Name = "lblEnterData";
            this.lblEnterData.Size = new System.Drawing.Size(345, 26);
            this.lblEnterData.TabIndex = 0;
            this.lblEnterData.Text = "Enter data for new book below:";
            // 
            // lblISBNDash
            // 
            this.lblISBNDash.AutoSize = true;
            this.lblISBNDash.Location = new System.Drawing.Point(816, 146);
            this.lblISBNDash.Name = "lblISBNDash";
            this.lblISBNDash.Size = new System.Drawing.Size(19, 25);
            this.lblISBNDash.TabIndex = 18;
            this.lblISBNDash.Text = "-";
            // 
            // btnDoneAdd
            // 
            this.btnDoneAdd.Location = new System.Drawing.Point(489, 663);
            this.btnDoneAdd.Name = "btnDoneAdd";
            this.btnDoneAdd.Size = new System.Drawing.Size(135, 37);
            this.btnDoneAdd.TabIndex = 19;
            this.btnDoneAdd.Text = "Done";
            this.btnDoneAdd.UseVisualStyleBackColor = true;
            this.btnDoneAdd.Click += new System.EventHandler(this.btnDoneAdd_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(955, 663);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(138, 37);
            this.btnExit.TabIndex = 20;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnDoneUpdate
            // 
            this.btnDoneUpdate.Location = new System.Drawing.Point(721, 663);
            this.btnDoneUpdate.Name = "btnDoneUpdate";
            this.btnDoneUpdate.Size = new System.Drawing.Size(134, 37);
            this.btnDoneUpdate.TabIndex = 21;
            this.btnDoneUpdate.Text = "Done";
            this.btnDoneUpdate.UseVisualStyleBackColor = true;
            this.btnDoneUpdate.Click += new System.EventHandler(this.btnDoneUpdate_Click);
            // 
            // frmTransactionSelect
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(1119, 712);
            this.Controls.Add(this.btnDoneUpdate);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDoneAdd);
            this.Controls.Add(this.lblISBNDash);
            this.Controls.Add(this.grpInventoryChangeControls);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.txtISBN2);
            this.Controls.Add(this.txtISBN1);
            this.Controls.Add(this.btnDeleteBook);
            this.Controls.Add(this.btnUpdateBook);
            this.Controls.Add(this.btnAddNewBook);
            this.Controls.Add(this.lblSelectTransaction);
            this.Controls.Add(this.lblEnterISBN);
            this.Controls.Add(this.lblTransactionPage);
            this.Controls.Add(this.lblBookStore);
            this.Controls.Add(this.lblBookWorm);
            this.Name = "frmTransactionSelect";
            this.Text = "TransactionSelect";
            this.Load += new System.EventHandler(this.frmTransactionSelect_Load);
            this.grpInventoryChangeControls.ResumeLayout(false);
            this.grpInventoryChangeControls.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookStore;
        private System.Windows.Forms.Label lblBookWorm;
        private System.Windows.Forms.Label lblTransactionPage;
        private System.Windows.Forms.Label lblEnterISBN;
        private System.Windows.Forms.Label lblSelectTransaction;
        private System.Windows.Forms.Button btnAddNewBook;
        private System.Windows.Forms.Button btnUpdateBook;
        private System.Windows.Forms.Button btnDeleteBook;
        private System.Windows.Forms.TextBox txtISBN1;
        private System.Windows.Forms.TextBox txtISBN2;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.GroupBox grpInventoryChangeControls;
        private System.Windows.Forms.Label lblEnterData;
        private System.Windows.Forms.Label lblISBNDash;
        private System.Windows.Forms.Button btnDoneAdd;
        private System.Windows.Forms.Label lblTransactionDate;
        private System.Windows.Forms.Label lblOnHand;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblISBN;
        private System.Windows.Forms.Button btnNo;
        private System.Windows.Forms.Button btnYes;
        private System.Windows.Forms.TextBox txtTransactionDate;
        private System.Windows.Forms.TextBox txtOnHand;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnDoneUpdate;
    }
}